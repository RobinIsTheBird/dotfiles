#!/usr/bin/env bash
# Intended to be sourced from .bash_profile

PATH=~/bin:~/node_modules/.bin:$PATH
