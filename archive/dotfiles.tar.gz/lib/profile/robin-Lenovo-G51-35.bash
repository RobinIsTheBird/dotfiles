#!/usr/bin/env bash
# Intended to be sourced from .bash_profile
. $HOME/lib/common/prime_sudo_cache.bash
. $HOME/lib/common/systemdetect.bash
. $HOME/lib/profile/ubuntu_env.bash
. $HOME/lib/profile/at_home/do_mount.bash
. $HOME/lib/profile/env.bash
. $HOME/lib/profile/ssh.bash
