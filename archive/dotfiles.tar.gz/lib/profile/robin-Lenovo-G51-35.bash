#!/usr/bin/env bash
# Intended to be sourced from .bash_profile
. $HOME/lib/profile/ssh.bash
