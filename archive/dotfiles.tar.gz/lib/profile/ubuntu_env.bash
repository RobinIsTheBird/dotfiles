#!/usr/bin/env bash
# Intended to be sourced from .bash_profile

PATH=/usr/local/go/bin:$PATH
. $HOME/lib/profile/as_sudo.bash
